package com.wakeguard.ai

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import androidx.core.app.NotificationCompat

class AlarmService : Service() {
    private var player: MediaPlayer? = null
    private var eyeWindowMs: Long = 60_000L
    private var confirmMs: Long = 5_000L

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopAlarm()
            return START_NOT_STICKY
        }

        eyeWindowMs = intent?.getLongExtra("eye_window_ms", 60_000L) ?: 60_000L
        confirmMs = intent?.getLongExtra("confirm_ms", 5_000L) ?: 5_000L
        createChannel()
        startForeground(NOTIFICATION_ID, buildNotification())
        startAlarmSound()
        return START_STICKY
    }

    private fun createChannel() {
        val manager = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Wake-up alarm", NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "WAKEGUARD repeating alarm notification"
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            }
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val openIntent = Intent(this, WakeCheckActivity::class.java).apply {
            putExtra("eye_window_ms", eyeWindowMs)
            putExtra("confirm_ms", confirmMs)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }
        val fullScreen = PendingIntent.getActivity(
            this, 2021, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = Intent(this, AlarmService::class.java).setAction(ACTION_STOP)
        val stopPending = PendingIntent.getService(
            this, 2022, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("WAKEGUARD AI — Wake up")
            .setContentText("Tap to start the eye-state wake check.")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setFullScreenIntent(fullScreen, true)
            .setContentIntent(fullScreen)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_media_pause, "Stop alarm", stopPending)
            .build()
    }

    private fun startAlarmSound() {
        try {
            val sound: Uri = Settings.System.DEFAULT_ALARM_ALERT_URI
            player?.release()
            player = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                setDataSource(this@AlarmService, sound)
                isLooping = true
                setOnPreparedListener { it.start() }
                prepareAsync()
            }
        } catch (_: Exception) {
            // Device may not have a default alarm tone configured.
        }
    }

    private fun stopAlarm() {
        player?.run {
            try { stop() } catch (_: Exception) {}
            release()
        }
        player = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        player?.release()
        player = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_STOP = "com.wakeguard.ai.STOP_ALARM"
        private const val CHANNEL_ID = "wakeguard_alarm"
        private const val NOTIFICATION_ID = 2202
    }
}
