package com.wakeguard.ai

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val serviceIntent = Intent(context, AlarmService::class.java).apply {
            putExtra("eye_window_ms", intent.getLongExtra("eye_window_ms", 60_000L))
            putExtra("confirm_ms", intent.getLongExtra("confirm_ms", 5_000L))
        }
        ContextCompat.startForegroundService(context, serviceIntent)
    }
}
