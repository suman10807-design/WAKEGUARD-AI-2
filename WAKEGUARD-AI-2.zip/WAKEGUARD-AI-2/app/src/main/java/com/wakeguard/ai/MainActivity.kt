package com.wakeguard.ai

import android.Manifest
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.TimePicker
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.Calendar

class MainActivity : AppCompatActivity() {
    private lateinit var eyeWindowInput: EditText
    private lateinit var confirmInput: EditText
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(8, 11, 24)
        window.navigationBarColor = android.graphics.Color.rgb(8, 11, 24)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(42, 48, 42, 32)
            setBackgroundColor(android.graphics.Color.rgb(8, 11, 24))
        }

        val title = TextView(this).apply {
            text = "WAKEGUARD AI 2.0"
            textSize = 27f
            setTextColor(0xFFFFFFFF.toInt())
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        root.addView(title)

        val subtitle = TextView(this).apply {
            text = "SMART WAKE-UP SYSTEM  •  EYE-STATE CHECK"
            textSize = 12f
            setTextColor(0xFF00D4FF.toInt())
            setPadding(0, 8, 0, 28)
        }
        root.addView(subtitle)

        val timeLabel = label("Set alarm time")
        root.addView(timeLabel)
        val timePicker = TimePicker(this).apply {
            setIs24HourView(true)
        }
        root.addView(timePicker)

        root.addView(label("Eye-check duration (minutes) — default 1"))
        eyeWindowInput = EditText(this).apply {
            setText("1")
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFF9AA4C0.toInt())
            setHint("Minutes")
        }
        root.addView(eyeWindowInput)

        root.addView(label("Continuous both-eyes-open confirmation (seconds)"))
        confirmInput = EditText(this).apply {
            setText("5")
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFF9AA4C0.toInt())
            setHint("Seconds")
        }
        root.addView(confirmInput)

        val schedule = Button(this).apply {
            text = "SCHEDULE ALARM"
            setOnClickListener {
                val windowMinutes = eyeWindowInput.text.toString().toIntOrNull()
                val confirmSeconds = confirmInput.text.toString().toIntOrNull()
                if (windowMinutes == null || windowMinutes !in 1..60 ||
                    confirmSeconds == null || confirmSeconds !in 1..60) {
                    status.text = "Enter 1–60 minutes and 1–60 confirmation seconds."
                    return@setOnClickListener
                }
                scheduleAlarm(timePicker.hour, timePicker.minute, windowMinutes, confirmSeconds)
            }
        }
        root.addView(schedule)

        val checkNow = Button(this).apply {
            text = "OPEN EYE CHECK"
            setOnClickListener {
                val intent = Intent(this@MainActivity, WakeCheckActivity::class.java)
                    .putExtra("eye_window_ms", 60_000L)
                    .putExtra("confirm_ms", 5_000L)
                startActivity(intent)
            }
        }
        root.addView(checkNow)

        status = TextView(this).apply {
            text = "Ready. Set an alarm to begin."
            textSize = 14f
            setTextColor(0xFFB8C4E0.toInt())
            setPadding(0, 20, 0, 0)
        }
        root.addView(status)

        val scroll = android.widget.ScrollView(this).apply { addView(root) }
        setContentView(scroll)

        requestNotificationPermissionIfNeeded()
    }

    private fun label(value: String) = TextView(this).apply {
        text = value
        textSize = 14f
        setTextColor(0xFFB8C4E0.toInt())
        setPadding(0, 18, 0, 4)
    }

    private fun scheduleAlarm(hour: Int, minute: Int, windowMinutes: Int, confirmSeconds: Int) {
        val alarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !alarmManager.canScheduleExactAlarms()) {
            status.text = "Allow exact alarms in Android settings, then return and schedule again."
            startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                Uri.parse("package:$packageName")))
            return
        }

        val calendar = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }

        val intent = Intent(this, AlarmReceiver::class.java).apply {
            putExtra("eye_window_ms", windowMinutes * 60_000L)
            putExtra("confirm_ms", confirmSeconds * 1_000L)
        }
        val pending = PendingIntent.getBroadcast(
            this, 2020, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, calendar.timeInMillis, pending)
        status.text = "Alarm scheduled for %02d:%02d.".format(hour, minute)
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 40)
        }
    }
}
