package com.wakeguard.ai

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.SystemClock
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.Face
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import java.util.concurrent.Executors

class WakeCheckActivity : AppCompatActivity() {
    private lateinit var preview: PreviewView
    private lateinit var status: TextView
    private lateinit var timerText: TextView
    private val cameraExecutor = Executors.newSingleThreadExecutor()
    private val detector by lazy {
        val options = FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
            .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL)
            .enableTracking()
            .build()
        FaceDetection.getClient(options)
    }

    private var eyeWindowMs = 60_000L
    private var confirmMs = 5_000L
    private var checkStartedAt = 0L
    private var eyesOpenSince = 0L
    private var finished = false

    private val cameraPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startCamera() else status.text = "Camera permission is required for the eye check."
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        eyeWindowMs = intent.getLongExtra("eye_window_ms", 60_000L).coerceIn(60_000L, 3_600_000L)
        confirmMs = intent.getLongExtra("confirm_ms", 5_000L).coerceIn(1_000L, 60_000L)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 24)
            setBackgroundColor(0xFF080B18.toInt())
        }
        val heading = TextView(this).apply {
            text = "WAKE CHECK"
            textSize = 25f
            setTextColor(0xFFFFFFFF.toInt())
        }
        root.addView(heading)
        status = TextView(this).apply {
            text = "Preparing front camera…"
            textSize = 16f
            setTextColor(0xFF00D4FF.toInt())
            setPadding(0, 12, 0, 12)
        }
        root.addView(status)
        timerText = TextView(this).apply {
            text = "Keep both eyes open"
            textSize = 14f
            setTextColor(0xFFB8C4E0.toInt())
        }
        root.addView(timerText)
        preview = PreviewView(this).apply {
            scaleType = PreviewView.ScaleType.FILL_CENTER
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        }
        root.addView(preview, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))
        val stop = android.widget.Button(this).apply {
            text = "STOP ALARM MANUALLY"
            setOnClickListener { stopAlarmAndFinish() }
        }
        root.addView(stop)
        setContentView(root)

        checkStartedAt = SystemClock.elapsedRealtime()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED) startCamera()
        else cameraPermission.launch(Manifest.permission.CAMERA)
    }

    private fun startCamera() {
        status.text = "Starting front camera…"
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            try {
                val provider = providerFuture.get()
                val previewUseCase = androidx.camera.core.Preview.Builder().build().also {
                    it.setSurfaceProvider(preview.surfaceProvider)
                }
                val analysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()
                analysis.setAnalyzer(cameraExecutor) { imageProxy -> analyze(imageProxy) }
                provider.unbindAll()
                provider.bindToLifecycle(
                    this, CameraSelector.DEFAULT_FRONT_CAMERA, previewUseCase, analysis
                )
                runOnUiThread { status.text = "Camera active. Looking for your face…" }
            } catch (_: Exception) {
                runOnUiThread { status.text = "Could not start the front camera. Check camera availability." }
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun analyze(proxy: ImageProxy) {
        val mediaImage = proxy.image
        if (mediaImage == null || finished) {
            proxy.close()
            return
        }
        val image = InputImage.fromMediaImage(mediaImage, proxy.imageInfo.rotationDegrees)
        detector.process(image)
            .addOnSuccessListener { faces -> processFaces(faces) }
            .addOnFailureListener {
                runOnUiThread { status.text = "Eye detection is temporarily unavailable." }
            }
            .addOnCompleteListener { proxy.close() }
    }

    private fun processFaces(faces: List<Face>) {
        if (finished) return
        val now = SystemClock.elapsedRealtime()
        if (now - checkStartedAt > eyeWindowMs) {
            runOnUiThread {
                status.text = "Check time ended. Keep the alarm active and try again."
                timerText.text = "Time limit reached"
            }
            eyesOpenSince = 0L
            return
        }

        val face = faces.maxByOrNull { it.boundingBox.width() * it.boundingBox.height() }
        val left = face?.leftEyeOpenProbability
        val right = face?.rightEyeOpenProbability
        val bothOpen = left != null && right != null && left >= 0.70f && right >= 0.70f

        if (face == null) {
            eyesOpenSince = 0L
            runOnUiThread {
                status.text = "No face detected. Face the front camera."
                timerText.text = "Move into the camera view"
            }
            return
        }

        if (!bothOpen) {
            eyesOpenSince = 0L
            runOnUiThread {
                status.text = if (left == null || right == null)
                    "Eyes not clearly detected. Improve lighting and face the camera."
                else "Both eyes must be open. Keep looking at the camera."
                timerText.text = "Confirmation timer reset"
            }
            return
        }

        if (eyesOpenSince == 0L) eyesOpenSince = now
        val elapsed = now - eyesOpenSince
        val remaining = (confirmMs - elapsed).coerceAtLeast(0L)
        runOnUiThread {
            status.text = "Both eyes detected open. Keep them open."
            timerText.text = "Confirming: %.1f seconds remaining".format(remaining / 1000f)
        }
        if (elapsed >= confirmMs) {
            finished = true
            runOnUiThread {
                status.text = "Wake check complete. Alarm stopped."
                timerText.text = "Have a good day."
                stopAlarmService()
                finishAfterDelay()
            }
        }
    }

    private fun stopAlarmService() {
        startService(Intent(this, AlarmService::class.java).setAction(AlarmService.ACTION_STOP))
    }

    private fun stopAlarmAndFinish() {
        finished = true
        stopAlarmService()
        finish()
    }

    private fun finishAfterDelay() {
        preview.postDelayed({ finish() }, 1200)
    }

    override fun onDestroy() {
        try { detector.close() } catch (_: Exception) {}
        cameraExecutor.shutdown()
        super.onDestroy()
    }
}
