# WAKEGUARD AI 2.0 — Smart Wake-up System

A new Android alarm project built with Kotlin, CameraX, and Google ML Kit. This repository is separate from the older `WAKEGUARD-AI` repository.

## Features

- Repeating alarm audio using the device's default alarm sound.
- Front-camera face and eye-open probability detection using ML Kit.
- Default wake-check window: 1 minute.
- Adjustable eye-check duration and continuous eyes-open confirmation duration.
- The alarm is stopped only after **both** eyes are reported open continuously for the selected confirmation duration.
- Status messages for camera permission, face visibility, eye state, and confirmation progress.
- GitHub Actions workflow to build a debug APK.

## Build an APK with GitHub Actions

1. Create a **new public** GitHub repository named `WAKEGUARD-AI-2`.
2. Extract this ZIP on your computer.
3. Open the extracted folder. Upload the *contents* of the folder (including `.github`, `app`, and the root Gradle files) to the repository root.
4. On GitHub, open **Actions** and enable workflows if prompted.
5. Select **Build WAKEGUARD AI 2.0 APK**, then choose **Run workflow**.
6. Wait for the workflow to finish successfully.
7. Open the completed workflow run, scroll to **Artifacts**, and download `WAKEGUARD-AI-2-debug-apk`.
8. Extract the artifact ZIP to find `app-debug.apk`.

The workflow uses JDK 17 and Gradle 8.9 on GitHub-hosted Ubuntu runners. The project uses the installed Gradle distribution in Actions, so a Gradle wrapper JAR is not required. **This ZIP has not been compiled in this environment** because Gradle is not installed here; the first real compilation will happen in GitHub Actions.

## Run/build locally (optional)

With JDK 17 and Gradle 8.9 installed:

```bash
gradle assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`

## How it works

- `AlarmReceiver` receives the scheduled alarm and starts `AlarmService`.
- `AlarmService` plays the configured default alarm sound in a foreground service and posts an ongoing notification.
- The notification opens `WakeCheckActivity`.
- `WakeCheckActivity` opens the front camera and runs ML Kit face detection.
- A face counts as having both eyes open only when both left- and right-eye open probabilities are available and meet the configured threshold.
- The eye-open confirmation timer resets immediately when the face or either eye fails the check.
- When the selected continuous confirmation duration is reached, the activity asks the alarm service to stop.

## Important Android limitations and privacy

- Camera permission is requested only when the wake-check screen is opened. The camera is used for on-device face/eye analysis; camera frames are not uploaded by this app.
- Eye-open probabilities are estimates, not medical-grade measurements. Glasses, low light, camera angle, blinking, and some faces may prevent reliable detection.
- Android versions and manufacturers restrict background activity launches, exact alarms, full-screen alarm notifications, and foreground services. The alarm notification is the reliable fallback if Android does not allow the wake-check screen to open automatically.
- On Android 13+, allow notifications. On Android 12+, allow exact alarms in system settings if the app asks for it. Full-screen notification behavior depends on Android version and user/system settings.
- The app respects the device alarm audio stream and does not attempt to bypass silent mode, volume limits, or device controls.
- Force-stopping the app, rebooting the phone, battery restrictions, or manufacturer-specific task management can prevent alarms from firing. This initial version does not restore scheduled alarms after reboot.
- This is a starter project. Do not treat an alarm as a safety-critical wake-up guarantee.

## Project structure

```text
WAKEGUARD-AI-2/
├── .github/workflows/android.yml
├── app/
│   ├── build.gradle.kts
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/wakeguard/ai/
│       │   ├── MainActivity.kt
│       │   ├── AlarmReceiver.kt
│       │   ├── AlarmService.kt
│       │   └── WakeCheckActivity.kt
│       └── res/values/styles.xml
├── build.gradle.kts
├── gradle.properties
└── settings.gradle.kts
```
